import knex from 'knex';

const config = {
  client: 'mysql2',
  connection: {
    host: 'localhost',
    user: 'newuser',//new_user
    password: 'newpassword',//new_password
    database: 'newdatabase' //college
  }
};

// const config = {
//   client: 'mysql2',
//   connection: {
//     host: 'localhost',
//     port: 5001,
//     user: 'root',
//     password: 'admin',
//     database: 'sideeshtambe',
//     connectTimeout: 10000 // Increase timeout to 10 seconds
//   }
// };

const db = knex(config);

export default db;